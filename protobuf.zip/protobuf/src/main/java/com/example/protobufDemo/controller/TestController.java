package com.example.protobufDemo.controller;

import com.example.protobufDemo.model.RtaRequestModel;
import com.example.protobufDemo.model.RtaResponseModel;
import com.google.common.util.concurrent.RateLimiter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TestController {

    //single machine rate
    private final RateLimiter rateLimiter = RateLimiter.create(500);

    @RequestMapping("/index")
    @ResponseBody
    public String index() {
        test();
        return "testtest";
    }


/*/   @Post("match")
    @HttpFeatures(contentType = "application/x-protobuf", charset = "UTF-8")*/
    @RequestMapping(value = "/test", produces = "application/x-protobuf;charset=UTF-8")
    public void match(HttpServletRequest request, HttpServletResponse response) {

        long startTime = System.currentTimeMillis();

        RtaRequestModel.RtaRequest rtaRequestModel = null;
        try(InputStream stream=request.getInputStream()){
            byte[] requestBytes = IOUtils.toByteArray(stream);
            rtaRequestModel = RtaRequestModel.RtaRequest.parseFrom(requestBytes);
        }catch (Exception e){
            outputResponse(response, "", 0, startTime);
            return ;
        }
        System.out.println("接收：");
        System.out.println(rtaRequestModel);

        outputResponse(response, "1111", 1, startTime);
    }

    private void outputResponse(HttpServletResponse response, String id, int rtaCode, long startTime){
        RtaResponseModel.RtaResponse rtaResponse = RtaResponseModel.RtaResponse.newBuilder()
                .setRequestId(id)
                .setCode(rtaCode)
                .setProcessingTimeMs((int)(System.currentTimeMillis()-startTime))
                .build();

        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/x-protobuf;charset=UTF-8");
        try(OutputStream out = response.getOutputStream()){
            out.write(rtaResponse.toByteArray());
            out.flush();
        } catch (IOException e) {

        }
    }


    public static void test() {
        try {
            String url11 = "http://127.0.0.1:8022/test";
            URL url = new URL(url11);
            // 将url 以 open方法返回的urlConnection  连接强转为HttpURLConnection连接  (标识一个url所引用的远程对象连接)
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();// 此时cnnection只是为一个连接对象,待连接中
            // 设置连接输出流为true,默认false (post 请求是以流的方式隐式的传递参数)
            connection.setDoOutput(true);
            // 设置连接输入流为true
            connection.setDoInput(true);
            // 设置请求方式为post
            connection.setRequestMethod("POST");
            // post请求缓存设为false
            connection.setUseCaches(false);
            // 设置该HttpURLConnection实例是否自动执行重定向
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Content-Type", "application/x-protobuf;charset=utf-8");
            connection.connect();

            // 创建输入输出流,用于往连接里面输出携带的参数
            DataOutputStream dataout = new DataOutputStream(connection.getOutputStream());

            RtaRequestModel.RtaRequest rtaRequest = RtaRequestModel.RtaRequest.newBuilder()
                    .setId("ukId")
                    .setIsPing(false)
                    .setIsTest(false)
                    .setDevice(RtaRequestModel.RtaRequest.Device.newBuilder()
                            .setOs(RtaRequestModel.RtaRequest.OperatingSystem.OS_IOS)
                            .setIdfaMd5Sum("95d4c8670b7f8546e5cccf85488c0b82")
                            .setIp("127.0.0.1")
                            .build())
                    .build();
            System.out.println("发送：");
            System.out.println(rtaRequest);
            dataout.write(rtaRequest.toByteArray());
            // 输出完成后刷新并关闭流
            dataout.flush();
            dataout.close();

            // 连接发起请求,处理服务器响应  (从连接获取到输入流并包装为bufferedReader)
            InputStream inputStream = connection.getInputStream();
            byte[] bbb = IOUtils.toByteArray(inputStream);
            for (byte b : bbb) {
                System.out.print(b + ",");
            }
            inputStream.close();    // 重要且易忽略步骤 (关闭流,切记!)
            connection.disconnect(); // 销毁连接

            System.out.println("返回：");
            RtaResponseModel.RtaResponse responseModel = RtaResponseModel.RtaResponse.parseFrom(bbb);
            System.out.println(responseModel);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
