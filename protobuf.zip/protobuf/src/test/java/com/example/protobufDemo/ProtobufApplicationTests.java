package com.example.protobufDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProtobufApplicationTests {

    @Test
    void contextLoads() {
    }

}
