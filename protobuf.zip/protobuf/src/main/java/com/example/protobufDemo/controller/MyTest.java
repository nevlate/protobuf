package com.example.protobufDemo.controller;

import com.example.protobufDemo.model.RtaRequestModel;
import com.example.protobufDemo.model.RtaResponseModel;
import com.google.protobuf.InvalidProtocolBufferException;

import java.io.UnsupportedEncodingException;

public class MyTest {

    public static void main(String[] args) throws InvalidProtocolBufferException {

        RtaResponseModel.RtaResponse rtaResponse = RtaResponseModel.RtaResponse.newBuilder()
                .setRequestId("rerrrr")
                .setCode(1)
                .setProcessingTimeMs(22)
        //        .setExcludeAdvertiserId(1,1)
                .build();
        System.out.println("=====RtaResponseModel===========");
        for (byte b : rtaResponse.toByteArray()) {
            System.out.print(b);
        }

        RtaResponseModel.RtaResponse trans = RtaResponseModel.RtaResponse.parseFrom(rtaResponse.toByteArray());

        System.out.println();
        System.out.println(trans);

        System.out.println("================");

        RtaRequestModel.RtaRequest rtaRequest = RtaRequestModel.RtaRequest.newBuilder()
                .setId("ukId")
                .setIsPing(true)
                .setIsTest(true)
                .setDevice(RtaRequestModel.RtaRequest.Device.newBuilder()
                        .setOs(RtaRequestModel.RtaRequest.OperatingSystem.OS_IOS)
                        .setIdfaMd5Sum("ttttt")
                        .setIp("127.0.0.1")
                        .build())
                .build();
        System.out.println(rtaRequest);
        System.out.println("=====RtaRequest===========");

        for (byte b : rtaRequest.toByteArray()) {
            System.out.print(b+",");
        }

        RtaRequestModel.RtaRequest rtaRequestModel = RtaRequestModel.RtaRequest.parseFrom(rtaRequest.toByteArray());

        System.out.println();
        System.out.println(rtaRequestModel);
    }

}
